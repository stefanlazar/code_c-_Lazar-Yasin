#include "Interpolation.h"

Interpolation::Interpolation(void)
{
}
Interpolation::~Interpolation(void)
{
}
double Interpolation::interpol_lagrange(std::vector<double> u,std::vector<double> x, double alpha)
{
	//u represents our vector in the y-axis (vertical), in fact, it's our initial price vector given by different methods.
	//x is the x-axis (horizontal), so here, it's the log-price vector of the underlying.
	//alpha is the point where we want to calculate value of the function, here, it's the initial log-price of the underlying.
double res;
double temp;
int M=x.size()-1;

std::vector<double> f;
//Since f is a "vector", we must to initialise it in order to fix its size.
for(int m=0;m<=M;m++)
{
	f.push_back(0);
}

int k;
for(int i=0;i<=M;i++)
{
	temp=1;
    k = i;
    for(int j=0;j<=M;j++)
    {
      if(k==j)
      {
        continue;
      }
      else
      {
        temp = temp * ((alpha-x[j])/(x[k]-x[j])); //Temp is Lagrange coefficient
      }
    }
    f[i]=u[i]*temp;
}

res=f[0];
for(int n=1;n<=M;n++)
{
	res+=f[n];
}
	return res;//Value of the function in alpha (The initial price of the option) 
}
