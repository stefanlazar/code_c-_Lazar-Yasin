#include "PayOff_Put.h"
using namespace std;

PayOff_Put::PayOff_Put(void)
{
}
PayOff_Put::PayOff_Put(double _K)
{
	K=_K;
}
PayOff_Put::~PayOff_Put(void)
{
}
double PayOff_Put::getStrike(void)
{
	return K;
}
double PayOff_Put::payoff(double S)
{
	return max(K-S,0.0);//Formula for put payoff
}
