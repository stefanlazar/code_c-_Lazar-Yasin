#pragma once
#include "PayOff.h"
#include <algorithm>
class PayOff_Call: public PayOff
{
public:
	PayOff_Call(void);
	PayOff_Call(double _K);
	~PayOff_Call(void);
	double payoff(double S);
private:
	double K;  //Strike Call
};

/*The call inherits our abstract PayOff class, a call is defined only by its payoff.
We only need the fixed price of the underlying at the maturity (strike).
The strike is defined in private so, we should write the getStrike method.*/
