#include <vector>
#pragma once
class Interpolation
{
public:
	Interpolation(void);
	~Interpolation(void);
	static double interpol_lagrange(std::vector<double> d,std::vector<double> x,double alpha);
};

/*This class serves to interpolate option price by using Lagrange method, we need it because log(S) might not be in 
points of discretisation in space.*/
