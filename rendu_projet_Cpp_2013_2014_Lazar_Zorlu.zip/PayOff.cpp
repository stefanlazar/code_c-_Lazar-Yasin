#include "PayOff.h"


PayOff::PayOff(void)
{
}
PayOff::~PayOff(void)
{
}
//We don't define any methods because it's an abstract class
