#include "Options_EU.h"

Options_EU::Options_EU(void)
{
}
Options_EU::~Options_EU(void)
{
}
Options_EU::Options_EU(double _T,PayOff* _pay_off)
{
	T=_T;
	pay_off=_pay_off;
	/*PayOff* pay_off=_pay_off;
	delete[] pay_off;  //we will build a new location for pay_off*/

}
double Options_EU::getMaturity(void)
{
	return T;
}
PayOff*  Options_EU::getPayOff(void)
{
	return pay_off;
}


//Here, there is only the constructor to define
