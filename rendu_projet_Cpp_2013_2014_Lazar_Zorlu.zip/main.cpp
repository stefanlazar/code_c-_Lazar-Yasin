#include <iostream>
using namespace std;
#include "Results_Display.h"

int main()
{
	Results_Display rd;//we build a Results_Display object
	rd.Handy_Way();
}