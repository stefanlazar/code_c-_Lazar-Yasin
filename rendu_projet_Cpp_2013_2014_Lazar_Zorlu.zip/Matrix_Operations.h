#pragma once
#include <vector>

class Matrix_Operations
{
public:
	Matrix_Operations(void);
	~Matrix_Operations(void);
	static std::vector<double> algorithme_thomas(std::vector<double> low, std::vector<double> diag, std::vector<double> up, std::vector<double> right);
	static std::vector<double> calcul_matriciel(std::vector<double> low, std::vector<double> diag, std::vector<double> up, std::vector<double> v);
};

//We define two methods which consist to usual operations on tridiagonal matrix : inversion (Thomas algorithm) and multiplication