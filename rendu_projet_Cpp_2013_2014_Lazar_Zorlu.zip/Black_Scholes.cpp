#include "Black_Scholes.h"
#include <iostream>
using namespace std;

Black_Scholes::Black_Scholes(void)
{
}

Black_Scholes::~Black_Scholes(void)
{
}
double Black_Scholes::normalDistribution(double x)
{
	if(x<-10.)return 0.; // return sensible values on limits
  if(x>10.)return 1.;
  // number of steps
  int N=1000;
  // range of integration
  double a=0,b=x;
  // local variables
  double s,h,sum=0.;
  // initialise the variables
  h=(b-a)/N;
  // add in the first few terms
  sum = sum + exp(-a*a/2.) + 4.*exp(-(a+h)*(a+h)/2.);
  // and the last one
  sum = sum + exp(-b*b/2.);
  // loop over terms 2 up to N-1
  for(int i=1;i<N/2;i++)
  {
    s = a + 2*i*h;
    sum = sum + 2.*exp(-s*s/2.);
    s = s + h;
    sum = sum + 4.*exp(-s*s/2.);
  }
  // complete the integral
  sum = 0.5 + h*sum/3./sqrt(8.*atan(1.));
  // return result
  return sum;
}
double Black_Scholes::callOptionPrice(double S,double t,double K,double r,double sigma,double T)
{
	if(S<1.e-14)return 0.; // check if asset worthless
  if(sigma<1.e-14) // check if sigma zero
  {
    if(S<K*exp(-r*(T-t)))return 0.;
    else return S-K*exp(-r*(T-t));
  }
  if(fabs(T-t)<1.e-14) // check if we are at maturity
  {
    if(S<K)return 0.;
    else return S-K;
  }
  // calculate option price
  double d1=(log(S/K) + (r+sigma*sigma/2.)*(T-t))/(sigma*sqrt(T-t));
  double d2=(log(S/K) + (r-sigma*sigma/2.)*(T-t))/(sigma*sqrt(T-t));
  return normalDistribution(d1)*S - normalDistribution(d2)*K*exp(-r*(T-t));
}
double Black_Scholes::putOptionPrice(double S,double t,double K,double r,double sigma,double T)
{
	if(S<1.e-14)return 0.; // check if asset worthless
  if(sigma<1.e-14) // check if sigma zero
  {
    if(S>K*exp(-r*(T-t)))return 0.;
    else return K*exp(-r*(T-t))-S;
  }
  if(fabs(T-t)<1.e-14) // check if we are at maturity
  {
    if(S>K)return 0.;
    else return K-S;
  }
  // calculate option price
  double d1=(log(S/K) + (r+sigma*sigma/2.)*(T-t))/(sigma*sqrt(T-t));
  double d2=(log(S/K) + (r-sigma*sigma/2.)*(T-t))/(sigma*sqrt(T-t));
  return normalDistribution(-d2)*K*exp(-r*(T-t))-normalDistribution(-d1)*S;
}
