#include "Pricing_DPE.h"

const double q=2.575829; //99% quantile of the standard normal distribution

Pricing_DPE::Pricing_DPE(void)
{
}
Pricing_DPE::~Pricing_DPE(void)
{
}
int Pricing_DPE::discretisation(double S0, Options_EU oe,int N,std::vector<double>& t, std::vector<double>& x, double r, double mu, double sigma)
{
		//t and x are by reference because discretisation doesn't return these vectors.
		//Next, we'll define empty vectors (x and t) in different methods, and we'll use them, so without reference, vectors value are not modified (in fact they are empty).

		double xmax=sigma*sqrt(oe.getMaturity())*q+log(S0)+(mu-(sigma)*(sigma))*oe.getMaturity(); //Left border in space, the smallest price of the underlying (derivated at 99%)
		double xmin=-sigma*sqrt(oe.getMaturity())*q+log(S0)+(mu-(sigma)*(sigma))*oe.getMaturity();//Right border, the highest value at 99%
	
		int M=sqrt(double(N))*(xmax-xmin)/(sqrt(oe.getMaturity())); //M is derivated to respect stability condition of finite difference methods, 
		//so in the main, we couldn't impose M but we only give N

		double dt=oe.getMaturity()/N;//Time step
		for (int i=0; i<=N;i++)
		{
			t.push_back(dt*i); //We begin at 0 (initial time) and finish at T (maturity)
		}

		double dx=(xmax-xmin)/M;//Space step
		for(int j=0;j<=M;j++)
		{
			x.push_back(j*dx+xmin);//We begin at xmin and finish at xmax
		}
		return M;
}
//There are all points of the grid

/*
	**************************************************************************************************************************************
	******************************************   EULER IMPLICIT   ************************************************************************
	**************************************************************************************************************************************

*/

double Pricing_DPE::Euler_Implicit(double S0, int N, Options_EU oe, double r, double mu, double sigma)
{
		double res;

		std::vector<double> t;
		std::vector<double> x;
		
		int M=discretisation(S0, oe, N, t, x, r, mu, sigma); //We need M which is number of points minus 1 in space
		//Now, t contains points in time
		//x contains points in space
	
		//We must to construct the terminal vector price (payoff) by using payoff of the option oe
		std::vector<double> u;
		for (int j=0;j<=M;j++)
		{	
			u.push_back(oe.getPayOff()->payoff(exp(x[j])));
		}

		//Once, we obtain the terminal vector price, we can apply algorithm of resolution
		//We derive coefficients of our system of equations
		//That system is obtained by approaching each partial differential of the Black-Scholes DPE by finite difference determinerd by the method (here is Euler Implicit)

		double diag=r*(t[2]-t[1])+1+(sigma*sigma)*(t[2]-t[1])/((x[2]-x[1])*(x[2]-x[1]));
		double up=-0.5*(sigma*sigma)*(t[2]-t[1])/((x[2]-x[1])*(x[2]-x[1]))-(r-0.5*sigma*sigma)*(t[2]-t[1])/(2*(x[2]-x[1]));
		double low=-0.5*(sigma*sigma)*(t[2]-t[1])/((x[2]-x[1])*(x[2]-x[1]))+(r-0.5*sigma*sigma)*(t[2]-t[1])/(2*(x[2]-x[1]));
		double right=1;
		double constant=-(sigma*sigma)*(t[2]-t[1])/((x[2]-x[1])*(x[2]-x[1]));

		std::vector<double> diag_v;//diag_v represents the diagonal vector (M+1 elements) of the matrix obtained by the method
		for(int i=0;i<=M;i++)
		{
			diag_v.push_back(diag);
		}

		std::vector<double> up_v;//up_v represents the vector just above the diagonal (M elements and its first element is not the same than others (first line of the matrix))
		up_v.push_back(constant);
		for(int i=1;i<=M-1;i++)
		{
			up_v.push_back(up);
		}

		std::vector<double> low_v;//low_v represents the vector just below the diagonal (its last element is different)
		for(int i=0;i<=M-1;i++)
		{
			low_v.push_back(low);
		}
		low_v.push_back(constant);

		//We constructed the matrix, there is the vector at right of the equality to be determined (M+1 elements)
		//Its last element is different because of limit conditions


		for(int i=0;i<=M-1;i++)
		{
			u[i]=right*u[i];
		}
		u[M]=u[M]+(1/right)*(r-0.5*sigma*sigma)*(t[2]-t[1])+(sigma*sigma)*(t[2]-t[1])/(x[2]-x[1]);

		for(int i=N;i>=0;i--)
		{
			u=Matrix_Operations::algorithme_thomas(low_v,diag_v,up_v,u);//We start at maturity and we move back in the time to otbain the initial vector price
		}
		//At the end of the loop, u is the initial vector price but we want only one price (because we now the price of the underlying today)


		double xzero=log(S0);
		Interpolation inter;
		res=inter.interpol_lagrange(u,x,xzero);//We use Interpolation to determine the price

		return res;
}

/*
	
	**************************************************************************************************************************************
	******************************************   EULER EXPLICIT   ************************************************************************
	**************************************************************************************************************************************

*/

double Pricing_DPE::Euler_Explicit(double S0, int N, Options_EU oe, double r, double mu, double sigma)
{
		double res1;
	
		std::vector<double> t;
		std::vector<double> x;
		
		int M=discretisation(S0, oe, N, t, x, r, mu, sigma); 

		std::vector<double> u;
		for (int j=0;j<=M;j++)
		{	
			u.push_back(oe.getPayOff()->payoff(exp(x[j])));
		}

		//Because the method is different (Euler Explicit), coefficients of the matrix are differents

		double a=r*(t[2]-t[1])+1;
		double diag=1-sigma*sigma*(t[2]-t[1])/((x[2]-x[1])*(x[2]-x[1]));
		double up=(r-0.5*sigma*sigma)*(t[2]-t[1])/(2*(x[2]-x[1]))+0.5*sigma*sigma*(t[2]-t[1])/((x[2]-x[1])*(x[2]-x[1]));
		double low=-(r-0.5*sigma*sigma)*(t[2]-t[1])/(2*(x[2]-x[1]))+0.5*sigma*sigma*(t[2]-t[1])/((x[2]-x[1])*(x[2]-x[1]));
		double constant=sigma*sigma*(t[2]-t[1])/((x[2]-x[1])*(x[2]-x[1]));

		std::vector<double> diag_v;//diagonal
		for(int i=0;i<=M;i++)
		{
			diag_v.push_back(diag);
		}

		std::vector<double> up_v;//vector just above the diagonal
		up_v.push_back(constant);
		for(int i=1;i<=M-1;i++)
		{
			up_v.push_back(up);
		}

		std::vector<double> low_v;//vector just below the diagonal
		for(int i=0;i<=M-1;i++)
		{
			low_v.push_back(low);
		}
		low_v.push_back(constant);


		for(int i=N;i>=0;i--)
		{
			u=Matrix_Operations::calcul_matriciel(low_v,diag_v,up_v,u);//We don't have a matrix to inverse but we do a multiplication by a vector
			u[M]=u[M]+(r-0.5*sigma*sigma)*(t[2]-t[1])+(sigma*sigma)*(t[2]-t[1])/(x[2]-x[1]);
			for(int l=0;l<=M;l++)
			{
				u[l]=(1/a)*u[l];
			}
		}
		
		double xzero=log(S0);
		Interpolation inter1;
		res1=inter1.interpol_lagrange(u,x,xzero);

		return res1;
}
/*

	**************************************************************************************************************************************
	******************************************   CRANK-NICHOLSON   ************************************************************************
	**************************************************************************************************************************************

*/

double Pricing_DPE::Crank_Nicholson(double S0, int N, Options_EU oe, double r, double mu, double sigma)
{
		double res2;
	
		std::vector<double> t;
		std::vector<double> x;
		
		int M=discretisation(S0, oe, N, t, x, r, mu, sigma); 

		std::vector<double> u;
		for (int j=0;j<=M;j++)
		{	
			u.push_back(oe.getPayOff()->payoff(exp(x[j])));
		}

		//With the Crank-Nicholson method, we obtain two tridiagonals matrix, one at left of the equality and the other at right

		double diag_left=r*(t[2]-t[1])+1+0.5*(sigma*sigma)*(t[2]-t[1])/((x[2]-x[1])*(x[2]-x[1]));
		double up=0.25*(r-0.5*(sigma*sigma))*(t[2]-t[1])/(x[2]-x[1])+0.25*(sigma*sigma)*(t[2]-t[1])/((x[2]-x[1])*(x[2]-x[1]));
		double low=-0.25*(r-0.5*(sigma*sigma))*(t[2]-t[1])/(x[2]-x[1])+0.25*(sigma*sigma)*(t[2]-t[1])/((x[2]-x[1])*(x[2]-x[1]));
		double diag_right=1-0.5*(sigma*sigma)*(t[2]-t[1])/((x[2]-x[1])*(x[2]-x[1]));
		double constant=0.5*(sigma*sigma)*(t[2]-t[1])/((x[2]-x[1])*(x[2]-x[1]));

		//Matrix right 

		std::vector<double> up_right_v;
		up_right_v.push_back(constant);
		for(int i=0;i<=M-1;i++)
		{
			up_right_v.push_back(up);
		}
		std::vector<double> low_right_v;
		for(int i=1;i<=M-1;i++)
		{
			low_right_v.push_back(low);
		}
		low_right_v.push_back(constant);

		std::vector<double> diag_right_v;
		for(int i=0;i<=M;i++)
		{
			diag_right_v.push_back(diag_right);
		}

		//Matrix left

		std::vector<double> up_left_v;
		up_left_v.push_back(-constant);
		for(int i=0;i<=M-1;i++)
		{
			up_left_v.push_back(-up);
		}

		std::vector<double> low_left_v;
		for(int i=1;i<=M-1;i++)
		{
			low_left_v.push_back(-low);
		}
		low_left_v.push_back(-constant);

		std::vector<double> diag_left_v;
		for(int i=0;i<=M;i++)
		{
			diag_left_v.push_back(diag_left);
		}


		

		for(int i=N;i>=0;i--)
		{
			u=Matrix_Operations::calcul_matriciel(low_right_v,diag_right_v,up_right_v,u);//At first, a multiplication must be done
			u[M]=u[M]+(r-0.5*sigma*sigma)*(t[2]-t[1])+(sigma*sigma)*(t[2]-t[1])/(x[2]-x[1]);

			u=Matrix_Operations::algorithme_thomas(low_left_v,diag_left_v,up_left_v,u);//Then, we must to inverse the matrix
		}

		double xzero=log(S0);
		Interpolation inter2;
		res2=inter2.interpol_lagrange(u,x,xzero);

		return res2;
}
