#include "Results_Display.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

Results_Display::Results_Display(void)
{
}
Results_Display::~Results_Display(void)
{
}
void Results_Display::Handy_Way(void)
{
	double S0;
	double t=0;
	double K;
	double r;
	double sigma;
	double mu;
	double T;
	double N;
	int option_choice;

	cout<<"Euopean vanilla option :"<<endl;
	cout<<"1- Call"<<endl;
	cout<<"2- Put"<<endl;
	cout<<"Wich type of european option do you want to price (1 or 2) ?"<<endl;
	cin>>option_choice;
	while((option_choice!=1) && (option_choice!=2))
	{
		cout<<"ERROR!"<<endl;
		cout<<"Wich type of european option do you want to price (1 or 2) ?"<<endl;
		cin>>option_choice;
	}
	
	/*the initial price*/
	cout<<"Give the initial underlying price : "<<endl;
	cin>>S0;
	while (S0<0)
	{
		cout <<"ERROR ! ";
		cout<<"Give the initial underlying price (positive number) : "<<endl;
		cin>>S0;
	}
	/*The strike*/
	cout<<"Give the strike : "<<endl;
	cin>>K;
	while (K<0)
	{
		cout <<"ERROR ! ";
		cout<<"Give the strike (positive number) : "<<endl;
		cin>>K;
	}
	/*The free risk rate*/
	cout<<"Give the free risk rate (between 0 and 1) : "<<endl;
	cin>>r;
	while ((r>1) || (r<=0.01))
	{
		cout <<"ERROR ! ";
		cout<<"Give the free risk rate (between 0 and 1) : "<<endl;
		cin>>r;
	}
	/*The volatility*/
	cout<<"Give the volatility (between 0 and 1) : "<<endl;
	cin>>sigma;
	while ((sigma>1) || (sigma<0))
	{
		cout <<"ERROR ! ";
		cout<<"Give the volatility (between 0 and 1) : "<<endl;
		cin>>sigma;
	}
	/*The maturity*/
	cout<<"Give the maturity : "<<endl;
	cin>>T;
	while (T<0)
	{
		cout <<"ERROR ! ";
		cout<<"Give the maturity (positive number) : "<<endl;
		cin>>T;
	}
	cout<<"Give the number of points in time (integer) : "<<endl;
	cin>>N;
	while (N<0)
	{
		cout <<"ERROR ! ";
		cout<<"Give the number of points in time (integer) : "<<endl;
		cin>>N;
	}
	/*The trend*/
	cout<<"Give the trend of the underlying (between 0 and 1) : "<<endl;
	cin>>mu;
	while ((mu>1) || (mu<0))
	{
		cout <<"ERROR ! ";
		cout<<"Give the trend of the underlying (between 0 and 1) : "<<endl;
		cin>>mu;
	}

	cout<<endl;

	PayOff* poff;   
	double BS;
	Black_Scholes option_price;

	if(option_choice==1)// for a call
	{
		poff=new PayOff_Call(K);
		BS=option_price.callOptionPrice(S0,t,K,r,sigma,T);

		
		
	}else  //for a put
	{
		poff=new PayOff_Put(K);
		BS=option_price.putOptionPrice(S0,t,K,r,sigma,T);
		
		
	}
	Options_EU oe(T,poff);
	double ei;//ei like Euler Implicit and so on
	double ee;
	double cn;
		

	ei=Pricing_DPE::Euler_Implicit(S0,N,oe, r, mu, sigma);
	ee=Pricing_DPE::Euler_Explicit(S0,N,oe, r, mu, sigma);
	cn=Pricing_DPE::Crank_Nicholson(S0,N,oe, r, mu, sigma);

	ofstream file("mytext.txt",ios::out|ios::trunc);//mytext is the file where it will be written results, we use it for writing (ios::out)
	//and we delete all of previous text after a new execution.

	if(file)
	{
		file<<"Price with Black & Scholes : "<<BS<<endl;
		file<<"Price with Euler Implicit : "<<ei<<endl;
		file<<"Price with Euler Explicit : "<<ee<<endl;
		file<<"Price with Crank-Nicholson : "<<cn<<endl;
		file.close();
	}else
	{
		cerr<<"Impossible to open the file!!!"<<endl;
	}
	//You can find the .txt file at the same address as your Cpp code
}
