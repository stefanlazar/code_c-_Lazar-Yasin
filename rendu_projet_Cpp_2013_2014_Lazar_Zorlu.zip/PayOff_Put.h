#pragma once
#include "PayOff.h"
#include <algorithm>
class PayOff_Put: public PayOff
{
public:
	PayOff_Put(void);
	PayOff_Put(double _K);
	~PayOff_Put(void);
	double payoff(double);
	double getStrike(void);
private:
	double K;  //Strike Put
};

//This class is build in the same way as PayOff_Call.h
