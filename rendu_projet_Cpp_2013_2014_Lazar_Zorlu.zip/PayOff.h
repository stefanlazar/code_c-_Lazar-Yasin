#pragma once
class PayOff
{
public:
	PayOff(void); //constructor
	~PayOff(void);
	virtual double payoff(double)=0; //virtual pure method
};

/*This first class is an abstract class which is used to define
different payoffs of European options*/