#pragma once
#include <vector>
#include "Options_EU.h"
#include "Interpolation.h"
#include "Matrix_Operations.h"


class Pricing_DPE
{
public:
	Pricing_DPE(void);
	~Pricing_DPE(void);
	static int discretisation(double S0, Options_EU oe, int N,std::vector<double>& t, std::vector<double>& x, double r, double mu, double sigma);
	static double Euler_Implicit(double _S0, int _N, Options_EU _oe, double r, double mu, double sigma);
	static double Euler_Explicit(double _S0, int _N, Options_EU _oe, double r, double mu, double sigma);
	static double Crank_Nicholson(double _S0, int _N, Options_EU _oe, double r, double mu, double sigma);

};
/*In this class, we define the three finite difference methods.
We need also "discretisation" to obtain our domain of points (time and space)
"mu" is the trend, "r" is the free risk rate and "sigma" is the volatility*/
