#include "PayOff_Call.h"
using namespace std;

PayOff_Call::PayOff_Call(void)
{
}
PayOff_Call::~PayOff_Call(void)
{
}
PayOff_Call::PayOff_Call(double _K)
{
	K=_K;
}
double PayOff_Call::payoff(double S)
{
	return max(S-K,0.0);//Formula for call payoff
}

//Our constructor takes in parameters only the strike
