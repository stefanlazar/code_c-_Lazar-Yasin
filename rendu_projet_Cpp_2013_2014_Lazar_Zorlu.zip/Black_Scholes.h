#pragma once
class Black_Scholes
{
public:
	Black_Scholes(void);
	~Black_Scholes(void);
	
	double normalDistribution(double x);
	double callOptionPrice(double S,double t,double K,double r,double sigma,double T);
	double putOptionPrice(double S,double t,double K,double r,double sigma,double T);
	double S;
	double t;
	double K;
	double r;
	double sigma;
	double T;
};

/*This class gives the analytical solution for a put and call, and we need to approach the cumulative distribution function of a standard normal distribution
Remark : in the file .cpp, we found cods on net for only the method that approaches the normal distribution.*/

