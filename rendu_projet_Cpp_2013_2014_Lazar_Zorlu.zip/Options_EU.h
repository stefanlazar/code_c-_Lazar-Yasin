#pragma once
#include "PayOff.h"

class Options_EU
{
public:
	Options_EU(void);
	Options_EU(double _T, PayOff* _pay_off);
	~Options_EU(void);
	double getMaturity(void);
	PayOff* getPayOff(void); 

private:
PayOff* pay_off;
double T;//maturity


};

/*The parameter mu (the trend) is only used to derive borders of discretisation in space.

Remark : we can replace mu by the free-risk rate without any problem (nowadays, these are close).

A Europen option takes in parameters a POINTER to a PayOff.*/
