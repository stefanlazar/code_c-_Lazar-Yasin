#include "PayOff_Call.h"
#include "PayOff_Put.h"
#include "Black_Scholes.h"
#include "Pricing_DPE.h"
#pragma once
class Results_Display
{
public:
	Results_Display(void);
	~Results_Display(void);
	void static Handy_Way(void);
};

//This class will be used in the main, thanks to it, we will have a simple code in the main function