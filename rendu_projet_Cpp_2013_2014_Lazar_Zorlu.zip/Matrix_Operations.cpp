#include "Matrix_Operations.h"

Matrix_Operations::Matrix_Operations(void)
{
}

Matrix_Operations::~Matrix_Operations(void)
{
}
std::vector<double> Matrix_Operations::algorithme_thomas(std::vector<double> low, std::vector<double> diag, std::vector<double> up, std::vector<double> right)
{
		//We identify our matrix to its vectors because it is tridiagonal
		//low represents the vector just below diagonal 
		//diag is the diagonal 
		//up represents the vector just above diagonal
		//The rest of the matrix has zero as coefficient

		//Note A this matrix
		//d is the vector defines as Ax=d, x is the solution (res here)
		
		std::vector<double> res;
		up[0]=up[0]/diag[0];
		right[0]=right[0]/diag[0];
		
		for(int i=1;i<=right.size()-2;i++)
		{
		up[i]=up[i]/(diag[i]-low[i-1]*up[i-1]);
		right[i]=(right[i]-low[i-1]*right[i-1])/(diag[i]-low[i-1]*up[i-1]);
		}
		
		right[right.size()-1]=(right[right.size()-1]-low[right.size()-2]*right[right.size()-2])/(diag[right.size()-1]-up[right.size()-2]*low[right.size()-2]);

		
		for(int k=0;k<=right.size()-1;k++)//We initialize the "vector" res to fix its size and then we do modifications
		{
			res.push_back(0);
		}
		
		res[right.size()-1]=right[right.size()-1];
		
		for(int i=right.size()-2;i>=0;i--)  //We go from the end and derive solution (backward method)
		{
		res[i]=right[i]-up[i]*res[i+1];
		}
		return res;
}

std::vector<double> Matrix_Operations::calcul_matriciel(std::vector<double> low, std::vector<double> diag, std::vector<double> up, std::vector<double> v)
{
	//As we explain above, we have a tridiagonal matrix.
	//But here, we want not to inverse this matrix but to derive A.v = res
	std::vector<double> res;
	res.push_back(diag[0]*v[0]+up[0]*v[1]);
	for(int j=0;j<=v.size()-3;j++)
	{
		res.push_back(low[j]*v[j]+diag[j+1]*v[j+1]+up[j+1]*v[j+2]);
	}
	res.push_back(low[v.size()-2]*v[v.size()-2]+diag[v.size()-1]*v[v.size()-1]);
	return res;
}